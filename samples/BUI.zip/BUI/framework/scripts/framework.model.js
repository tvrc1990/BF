
var MenuObj = {
    New: function () {
        var obj = {};

        var svrObj = SvrObj.New();

        obj.VM = svrObj.getMenuArray();

        obj.menuTplFactry = function (tempArray, tempHtml) {
            for (var i = 0; i < tempArray.length; i++) {
                if (tempArray[i].menus != null && tempArray[i].menus.length > 0) {
                    tempHtml += ' <li class="expand"><span>' + tempArray[i].text + '</span> <ul> '
                    tempHtml = this.menuTplFactry(tempArray[i].menus, tempHtml);
                    tempHtml += ' </ul> </li>'
                }
                else {
                    tempHtml += ' <li><span ms-click="clickMenu(this)" href=' + tempArray[i].href + '>' + tempArray[i].text + '</span></li> '
                }
            }
            return tempHtml;
        };

        obj.getMenuTpl = function () {
            return this.menuTplFactry(this.VM, '');
        };

        return obj;
    }
};

var ContentObj = {
    New: function () {
        var obj = {};

        obj.contentArray = new Array();

        obj.convert = function (menuDom) {

            var temp = {
                href: $(menuDom).attr('href'),
                text: $(menuDom).text(),
                ico: $(menuDom).attr('class'),
            };

            return temp;
        }

        return obj;
    }
};

_contentObj = ContentObj.New();

_menuObj = MenuObj.New();

var contentModel = avalon.define({
    $id: "contentController",

    contentArray: new Array(),

    open: function (menuDom) {     
        contentModel.contentArray.push(_contentObj.convert(menuDom));
    },

    close: function (index)
    {
        contentModel.contentArray.removeIndex(index);
    }

});

var menuModel = avalon.define({
    $id: "menuController",

    menuTemplate: _menuObj.getMenuTpl(),

    clickMenu: function (menuDom) {
        contentModel.open(menuDom);
    }

});


avalon.scan();
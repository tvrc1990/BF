$(function () {


    //$('#main_tools').height(document.body.scrollHeight / 4);
    //$('#main_menu').height(document.body.scrollHeight);
    //$('#main_content').height(document.body.scrollHeight);

    //function displaySubMenu(li) {
    //    var subMenu = li.getElementsByTagName("ul")[0];
    //    subMenu.style.display = "block";
    //}
    //function hideSubMenu(li) {
    //    var subMenu = li.getElementsByTagName("ul")[0];
    //    subMenu.style.display = "none";
    //}

    $('.menu-tree li').mouseover(function () {
        setTimeout(100,
        $(this).find('ul:first').show());
    }).mouseout(function () {
        setTimeout(100,
        $(this).find('ul:first').hide());
    });





});